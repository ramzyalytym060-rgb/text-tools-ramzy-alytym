"""
اختبارات حزمة أدوات النصوص
========================

ملف اختبار شامل لجميع دوال الحزمة.
"""

import sys
import os

# إضافة مسار الحزمة للاستيراد
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'text_tools_ramzy_alytym'))

from text_tools_ramzy_alytym.text_utils import (
    count_words,
    count_characters,
    reverse_text,
    reverse_words,
    clean_text,
    extract_numbers,
    extract_emails,
    to_title_case,
    get_text_statistics
)


def test_count_words():
    """اختبار دالة حساب الكلمات"""
    print("اختبار count_words:")
    
    # اختبارات مختلفة
    tests = [
        ("مرحبا بك في عالم البرمجة", 5),
        ("Hello World", 2),
        ("", 0),
        ("   ", 0),
        ("كلمة واحدة", 2),
        ("  مسافات  زائدة  في  البداية  والنهاية  ", 6)
    ]
    
    for text, expected in tests:
        result = count_words(text)
        status = "✓" if result == expected else "✗"
        print(f"  {status} '{text}' -> {result} (متوقع: {expected})")
    
    print()


def test_count_characters():
    """اختبار دالة حساب الأحرف"""
    print("اختبار count_characters:")
    
    tests = [
        ("مرحبا", True, 5),
        ("مرحبا بك", True, 8),
        ("مرحبا بك", False, 7),
        ("Hello World!", True, 12),
        ("", True, 0)
    ]
    
    for text, include_spaces, expected in tests:
        result = count_characters(text, include_spaces)
        status = "✓" if result == expected else "✗"
        spaces_text = "مع المسافات" if include_spaces else "بدون مسافات"
        print(f"  {status} '{text}' ({spaces_text}) -> {result} (متوقع: {expected})")
    
    print()


def test_reverse_text():
    """اختبار دالة عكس النص"""
    print("اختبار reverse_text:")
    
    tests = [
        ("مرحبا", "ابحرم"),
        ("Hello", "olleH"),
        ("12345", "54321"),
        ("", "")
    ]
    
    for text, expected in tests:
        result = reverse_text(text)
        status = "✓" if result == expected else "✗"
        print(f"  {status} '{text}' -> '{result}' (متوقع: '{expected}')")
    
    print()


def test_reverse_words():
    """اختبار دالة عكس ترتيب الكلمات"""
    print("اختبار reverse_words:")
    
    tests = [
        ("مرحبا بك في البرمجة", "البرمجة في بك مرحبا"),
        ("Hello World", "World Hello"),
        ("واحدة", "واحدة"),
        ("", "")
    ]
    
    for text, expected in tests:
        result = reverse_words(text)
        status = "✓" if result == expected else "✗"
        print(f"  {status} '{text}' -> '{result}' (متوقع: '{expected}')")
    
    print()


def test_clean_text():
    """اختبار دالة تنظيف النص"""
    print("اختبار clean_text:")
    
    tests = [
        ("  مرحبا    بك   في البرمجة  ", "مرحبا بك في البرمجة"),
        ("نص    مع مسافات     كثيرة", "نص مع مسافات كثيرة"),
        ("   ", ""),
        ("نص عادي", "نص عادي")
    ]
    
    for text, expected in tests:
        result = clean_text(text)
        status = "✓" if result == expected else "✗"
        print(f"  {status} '{text}' -> '{result}' (متوقع: '{expected}')")
    
    print()


def test_extract_numbers():
    """اختبار دالة استخراج الأرقام"""
    print("اختبار extract_numbers:")
    
    tests = [
        ("عمري 25 سنة ووزني 70.5 كيلو", ['25', '70.5']),
        ("لا يوجد أرقام هنا", []),
        ("123 و 456.789 و 0", ['123', '456.789', '0']),
        ("", [])
    ]
    
    for text, expected in tests:
        result = extract_numbers(text)
        status = "✓" if result == expected else "✗"
        print(f"  {status} '{text}' -> {result} (متوقع: {expected})")
    
    print()


def test_extract_emails():
    """اختبار دالة استخراج الإيميلات"""
    print("اختبار extract_emails:")
    
    tests = [
        ("تواصل معي على ahmed@example.com أو sara@gmail.com", 
         ['ahmed@example.com', 'sara@gmail.com']),
        ("لا يوجد إيميلات هنا", []),
        ("إيميلي هو test.email+tag@domain.co.uk", ['test.email+tag@domain.co.uk']),
        ("", [])
    ]
    
    for text, expected in tests:
        result = extract_emails(text)
        status = "✓" if result == expected else "✗"
        print(f"  {status} '{text}' -> {result} (متوقع: {expected})")
    
    print()


def test_to_title_case():
    """اختبار دالة تحويل إلى صيغة العنوان"""
    print("اختبار to_title_case:")
    
    tests = [
        ("welcome to python programming", "Welcome To Python Programming"),
        ("hello world", "Hello World"),
        ("ALREADY UPPERCASE", "Already Uppercase"),
        ("", "")
    ]
    
    for text, expected in tests:
        result = to_title_case(text)
        status = "✓" if result == expected else "✗"
        print(f"  {status} '{text}' -> '{result}' (متوقع: '{expected}')")
    
    print()


def test_get_text_statistics():
    """اختبار دالة الإحصائيات الشاملة"""
    print("اختبار get_text_statistics:")
    
    text = "مرحبا بك في عالم البرمجة! عمري 25 سنة. إيميلي test@example.com"
    result = get_text_statistics(text)
    
    print(f"  النص: '{text}'")
    print(f"  عدد الكلمات: {result['word_count']}")
    print(f"  عدد الأحرف (مع المسافات): {result['character_count']}")
    print(f"  عدد الأحرف (بدون مسافات): {result['character_count_no_spaces']}")
    print(f"  الأرقام: {result['numbers']}")
    print(f"  الإيميلات: {result['emails']}")
    
    print()


def run_all_tests():
    """تشغيل جميع الاختبارات"""
    print("=" * 50)
    print("تشغيل اختبارات حزمة أدوات النصوص")
    print("=" * 50)
    print()
    
    test_count_words()
    test_count_characters()
    test_reverse_text()
    test_reverse_words()
    test_clean_text()
    test_extract_numbers()
    test_extract_emails()
    test_to_title_case()
    test_get_text_statistics()
    
    print("=" * 50)
    print("انتهت الاختبارات!")
    print("=" * 50)


if __name__ == "__main__":
    run_all_tests()

