# Text Tools by Ramzy Alytym

مجموعة من الأدوات المفيدة للتعامل مع النصوص في بايثون، تدعم اللغة العربية والإنجليزية.

## المميزات

هذه الحزمة توفر مجموعة شاملة من الدوال للتعامل مع النصوص:

- **حساب الكلمات والأحرف**: دوال لحساب عدد الكلمات والأحرف مع خيارات متقدمة
- **معالجة النصوص**: عكس النص، عكس ترتيب الكلمات، تنظيف المسافات الزائدة
- **استخراج البيانات**: استخراج الأرقام وعناوين البريد الإلكتروني من النصوص
- **تحويل التنسيق**: تحويل النص إلى صيغة العنوان
- **إحصائيات شاملة**: الحصول على تحليل كامل للنص في دالة واحدة

## التثبيت

```bash
pip install text-tools-ramzy-alytym
```

## الاستخدام

### الاستيراد

```python
from text_tools_ramzy_alytym import (
    count_words,
    count_characters,
    reverse_text,
    reverse_words,
    clean_text,
    extract_numbers,
    extract_emails,
    to_title_case,
    get_text_statistics
)
```

### أمثلة الاستخدام

#### حساب الكلمات والأحرف

```python
text = "مرحبا بك في عالم البرمجة"

# حساب عدد الكلمات
word_count = count_words(text)
print(f"عدد الكلمات: {word_count}")  # النتيجة: 5

# حساب عدد الأحرف
char_count = count_characters(text)
print(f"عدد الأحرف: {char_count}")  # النتيجة: 23

# حساب عدد الأحرف بدون مسافات
char_count_no_spaces = count_characters(text, include_spaces=False)
print(f"عدد الأحرف بدون مسافات: {char_count_no_spaces}")  # النتيجة: 19
```

#### معالجة النصوص

```python
# عكس النص
reversed_text = reverse_text("مرحبا")
print(reversed_text)  # النتيجة: "ابحرم"

# عكس ترتيب الكلمات
reversed_words = reverse_words("مرحبا بك في البرمجة")
print(reversed_words)  # النتيجة: "البرمجة في بك مرحبا"

# تنظيف النص من المسافات الزائدة
clean = clean_text("  مرحبا    بك   في البرمجة  ")
print(clean)  # النتيجة: "مرحبا بك في البرمجة"
```

#### استخراج البيانات

```python
text = "عمري 25 سنة ووزني 70.5 كيلو، تواصل معي على ahmed@example.com"

# استخراج الأرقام
numbers = extract_numbers(text)
print(numbers)  # النتيجة: ['25', '70.5']

# استخراج عناوين البريد الإلكتروني
emails = extract_emails(text)
print(emails)  # النتيجة: ['ahmed@example.com']
```

#### تحويل التنسيق

```python
# تحويل إلى صيغة العنوان
title = to_title_case("welcome to python programming")
print(title)  # النتيجة: "Welcome To Python Programming"
```

#### الإحصائيات الشاملة

```python
text = "مرحبا بك في عالم البرمجة! عمري 25 سنة. إيميلي test@example.com"
stats = get_text_statistics(text)

print(f"عدد الكلمات: {stats['word_count']}")
print(f"عدد الأحرف: {stats['character_count']}")
print(f"عدد الأحرف بدون مسافات: {stats['character_count_no_spaces']}")
print(f"الأرقام: {stats['numbers']}")
print(f"الإيميلات: {stats['emails']}")
```

## الدوال المتاحة

| الدالة | الوصف | المعاملات | القيمة المرجعة |
|--------|--------|-----------|----------------|
| `count_words(text)` | حساب عدد الكلمات | `text: str` | `int` |
| `count_characters(text, include_spaces)` | حساب عدد الأحرف | `text: str, include_spaces: bool = True` | `int` |
| `reverse_text(text)` | عكس النص | `text: str` | `str` |
| `reverse_words(text)` | عكس ترتيب الكلمات | `text: str` | `str` |
| `clean_text(text)` | تنظيف النص | `text: str` | `str` |
| `extract_numbers(text)` | استخراج الأرقام | `text: str` | `List[str]` |
| `extract_emails(text)` | استخراج الإيميلات | `text: str` | `List[str]` |
| `to_title_case(text)` | تحويل لصيغة العنوان | `text: str` | `str` |
| `get_text_statistics(text)` | إحصائيات شاملة | `text: str` | `dict` |

## المتطلبات

- Python 3.7 أو أحدث
- لا توجد متطلبات خارجية (تستخدم المكتبات المدمجة فقط)

## الترخيص

هذا المشروع مرخص تحت رخصة MIT - راجع ملف [LICENSE](LICENSE) للتفاصيل.

## المساهمة

المساهمات مرحب بها! يرجى:

1. عمل Fork للمشروع
2. إنشاء فرع للميزة الجديدة (`git checkout -b feature/AmazingFeature`)
3. تنفيذ التغييرات (`git commit -m 'Add some AmazingFeature'`)
4. رفع التغييرات (`git push origin feature/AmazingFeature`)
5. فتح Pull Request

## الاختبارات

لتشغيل الاختبارات:

```bash
python test_text_tools.py
```

## المؤلف

**Ramzy Alytym**
- البريد الإلكتروني: ramzy.alytym@example.com
- GitHub: [@ramzy-alytym](https://github.com/ramzy-alytym)

## الإصدارات

### الإصدار 1.0.0
- الإصدار الأول من الحزمة
- 9 دوال أساسية للتعامل مع النصوص
- دعم اللغة العربية والإنجليزية
- اختبارات شاملة
- توثيق كامل

