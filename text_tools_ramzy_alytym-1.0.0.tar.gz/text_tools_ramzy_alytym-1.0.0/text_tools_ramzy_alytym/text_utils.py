"""
وحدة الأدوات النصية
==================

تحتوي على مجموعة من الدوال المفيدة للتعامل مع النصوص.
"""

import re
from typing import List


def count_words(text: str) -> int:
    """
    حساب عدد الكلمات في النص.
    
    Args:
        text (str): النص المراد حساب كلماته
        
    Returns:
        int: عدد الكلمات
        
    Example:
        >>> count_words("مرحبا بك في عالم البرمجة")
        5
    """
    if not text or not isinstance(text, str):
        return 0
    
    # إزالة المسافات الزائدة وتقسيم النص إلى كلمات
    words = text.strip().split()
    return len(words)


def count_characters(text: str, include_spaces: bool = True) -> int:
    """
    حساب عدد الأحرف في النص.
    
    Args:
        text (str): النص المراد حساب أحرفه
        include_spaces (bool): هل نحسب المسافات أم لا
        
    Returns:
        int: عدد الأحرف
        
    Example:
        >>> count_characters("مرحبا")
        5
        >>> count_characters("مرحبا بك", include_spaces=False)
        7
    """
    if not text or not isinstance(text, str):
        return 0
    
    if include_spaces:
        return len(text)
    else:
        return len(text.replace(" ", ""))


def reverse_text(text: str) -> str:
    """
    عكس النص بالكامل.
    
    Args:
        text (str): النص المراد عكسه
        
    Returns:
        str: النص المعكوس
        
    Example:
        >>> reverse_text("مرحبا")
        "ابحرم"
    """
    if not text or not isinstance(text, str):
        return ""
    
    return text[::-1]


def reverse_words(text: str) -> str:
    """
    عكس ترتيب الكلمات في النص.
    
    Args:
        text (str): النص المراد عكس كلماته
        
    Returns:
        str: النص مع ترتيب معكوس للكلمات
        
    Example:
        >>> reverse_words("مرحبا بك في البرمجة")
        "البرمجة في بك مرحبا"
    """
    if not text or not isinstance(text, str):
        return ""
    
    words = text.strip().split()
    return " ".join(reversed(words))


def clean_text(text: str) -> str:
    """
    تنظيف النص من المسافات الزائدة والأسطر الفارغة.
    
    Args:
        text (str): النص المراد تنظيفه
        
    Returns:
        str: النص المنظف
        
    Example:
        >>> clean_text("  مرحبا    بك   في البرمجة  ")
        "مرحبا بك في البرمجة"
    """
    if not text or not isinstance(text, str):
        return ""
    
    # إزالة المسافات من البداية والنهاية
    text = text.strip()
    
    # استبدال المسافات المتعددة بمسافة واحدة
    text = re.sub(r'\s+', ' ', text)
    
    return text


def extract_numbers(text: str) -> List[str]:
    """
    استخراج جميع الأرقام من النص.
    
    Args:
        text (str): النص المراد استخراج الأرقام منه
        
    Returns:
        List[str]: قائمة بالأرقام الموجودة في النص
        
    Example:
        >>> extract_numbers("عمري 25 سنة ووزني 70.5 كيلو")
        ['25', '70.5']
    """
    if not text or not isinstance(text, str):
        return []
    
    # البحث عن الأرقام (صحيحة وعشرية)
    numbers = re.findall(r'\d+\.?\d*', text)
    return numbers


def extract_emails(text: str) -> List[str]:
    """
    استخراج عناوين البريد الإلكتروني من النص.
    
    Args:
        text (str): النص المراد استخراج الإيميلات منه
        
    Returns:
        List[str]: قائمة بعناوين البريد الإلكتروني
        
    Example:
        >>> extract_emails("تواصل معي على ahmed@example.com أو sara@gmail.com")
        ['ahmed@example.com', 'sara@gmail.com']
    """
    if not text or not isinstance(text, str):
        return []
    
    # نمط البحث عن البريد الإلكتروني
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    emails = re.findall(email_pattern, text)
    return emails


def to_title_case(text: str) -> str:
    """
    تحويل النص إلى صيغة العنوان (أول حرف من كل كلمة كبير).
    
    Args:
        text (str): النص المراد تحويله
        
    Returns:
        str: النص في صيغة العنوان
        
    Example:
        >>> to_title_case("welcome to python programming")
        "Welcome To Python Programming"
    """
    if not text or not isinstance(text, str):
        return ""
    
    return text.title()


def get_text_statistics(text: str) -> dict:
    """
    الحصول على إحصائيات شاملة عن النص.
    
    Args:
        text (str): النص المراد تحليله
        
    Returns:
        dict: قاموس يحتوي على إحصائيات النص
        
    Example:
        >>> get_text_statistics("مرحبا بك في عالم البرمجة")
        {
            'word_count': 5,
            'character_count': 23,
            'character_count_no_spaces': 19,
            'numbers': [],
            'emails': []
        }
    """
    if not text or not isinstance(text, str):
        return {
            'word_count': 0,
            'character_count': 0,
            'character_count_no_spaces': 0,
            'numbers': [],
            'emails': []
        }
    
    return {
        'word_count': count_words(text),
        'character_count': count_characters(text, include_spaces=True),
        'character_count_no_spaces': count_characters(text, include_spaces=False),
        'numbers': extract_numbers(text),
        'emails': extract_emails(text)
    }

