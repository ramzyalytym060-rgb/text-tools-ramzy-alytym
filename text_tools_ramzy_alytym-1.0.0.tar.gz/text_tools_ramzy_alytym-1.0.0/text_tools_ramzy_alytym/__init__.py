"""
Text Tools by Ramzy Alytym
==========================

مجموعة من الأدوات المفيدة للتعامل مع النصوص في بايثون.

الوظائف المتاحة:
- count_words: حساب عدد الكلمات
- count_characters: حساب عدد الأحرف
- reverse_text: عكس النص
- reverse_words: عكس ترتيب الكلمات
- clean_text: تنظيف النص من المسافات الزائدة
- extract_numbers: استخراج الأرقام من النص
- extract_emails: استخراج عناوين البريد الإلكتروني
- to_title_case: تحويل النص إلى صيغة العنوان
"""

__version__ = "1.0.0"
__author__ = "Ramzy Alytym"
__email__ = "ramzy.alytym@example.com"

from .text_utils import (
    count_words,
    count_characters,
    reverse_text,
    reverse_words,
    clean_text,
    extract_numbers,
    extract_emails,
    to_title_case,
    get_text_statistics
)

__all__ = [
    'count_words',
    'count_characters', 
    'reverse_text',
    'reverse_words',
    'clean_text',
    'extract_numbers',
    'extract_emails',
    'to_title_case',
    'get_text_statistics'
]

